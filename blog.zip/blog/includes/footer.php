



    </div>


</body>	
	
	<!-- // container -->


		<div class="footer">
			
	
		<!-- // footer -->

	
      	<footer class="text-center large tm-footer">
          <p class="mb-0">
          Copyright &copy; 2020 Ascension Business Concern <?php echo date('Y'); ?>
         
        </footer>




    </section>
</html>




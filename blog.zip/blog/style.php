<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
* {
  box-sizing: border-box;
}

.row::after {
  content: "";
  clear: both;
  display: table;
}

[class*="col-"] {
  float: left;
  padding: 15px;
}

html {
  font-family: "Lucida Sans", sans-serif;
}

.header {
  background-color: #9933cc;
  color: #ffffff;
  padding: 15px;
}

.menu ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
}

.menu li {
  padding: 8px;
  text-align: center;
  margin-bottom: 7px;
  background-color: #33b5e5;
  color: #fff222;
  box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
}

.menu li:hover {
  background-color: #0099cc;
}

.aside {
  background-color: #bfe;
  padding: 15px;
  color: #ffffff;
  text-align: center;
  font-size: 14px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
}

.footer {
  background-color: #0099cc;
  color: #ffffff;
  text-align: center;
  font-size: 12px;
  padding: 15px;
  bottom: 0px;
}

/* For mobile phones: */
[class*="col-"] {
  width: 100%;
}

@media only screen and (min-width: 600px) {
  /* For tablets: */
  .col-s-1 {width: 8.33%;}
  .col-s-2 {width: 16.66%;}
  .col-s-3 {width: 25%;}
  .col-s-4 {width: 33.33%;}
  .col-s-5 {width: 41.66%;}
  .col-s-6 {width: 50%;}
  .col-s-7 {width: 58.33%;}
  .col-s-8 {width: 66.66%;}
  .col-s-9 {width: 75%;}
  .col-s-10 {width: 83.33%;}
  .col-s-11 {width: 91.66%;}
  .col-s-12 {width: 100%;}
}
@media only screen and (min-width: 768px) {
  /* For desktop: */
  .col-1 {width: 8.33%;}
  .col-2 {width: 16.66%;}
  .col-3 {width: 25%;}
  .col-4 {width: 33.33%;}
  .col-5 {width: 41.66%;}
  .col-6 {width: 50%;}
  .col-7 {width: 58.33%;}
  .col-8 {width: 66.66%;}
  .col-9 {width: 75%;}
  .col-10 {width: 83.33%;}
  .col-11 {width: 91.66%;}
  .col-12 {width: 100%;}
}
</style>
</head>
<body>

<div class="header">

  <!-- The first include should be config.php -->
<?php require_once('config.php') ?>
<?php require_once( ROOT_PATH . '/includes/public_functions.php') ?>
<?php require_once( ROOT_PATH . '/includes/registration_login.php') ?>

<!-- Retrieve all posts from database  -->
<?php $posts = getPublishedPosts(); ?>

<?php require_once( ROOT_PATH . '/includes/head_section.php') ?>
  <title>LifeBlog | Home </title>
</head>
<body>
  <!-- container - wraps whole page -->
<div class="container">
            <!-- navbar -->
            <?php include( ROOT_PATH . '/includes/navbar.php') ?>
            <!-- // navbar -->

            <!-- banner -->
            <?php include( ROOT_PATH . '/includes/banner.php') ?>
            <!-- // banner -->
        

<div class="row">
  <div class="col-3 col-s-3 menu">
    <ul>

      <li>       
          <?php $topics = getAllTopics();?>
          <?php foreach ($topics as $topic): ?>
          <a href="<?php echo BASE_URL . 'filtered_posts.php?topic=' . $topic['id'] ?>">&nbsp #<?php echo $topic['name']; ?>
          </a> 
          <?php endforeach ?></li>
     
    </ul>
  </div>
</div> <!-- row end -->

<section>
  <div class="col-6 col-s-9">
    <h1>content</h1>
    <div class="content">
      <h2 class="content-title"> title here</h2>
      <hr> 
      <!-- more content still to come here ... -->
      <?php foreach ($posts as $post): ?>
        <div class="post" style="margin-left: 0px;">
          <img src="<?php echo BASE_URL . '/static/images/' . $post['image']; ?>" class="post_image" alt="">
              <!-- Added this if statement... -->
          <?php if (isset($post['topic']['name'])): ?>
            <a href="<?php echo BASE_URL . 'filtered_posts.php?topic=' . $post['topic']['id'] ?>"class="btn category"><?php echo $post['topic']['name'] ?> </a>
          <?php endif ?>
          <a href="single_post.php?post-slug=<?php echo $post['slug']; ?>">
            <div class="post_info">
              <h3><?php echo $post['title'] ?></h3>
              <div class="info">
                <span><?php echo date("F j, Y ", strtotime($post["created_at"])); ?></span>
                <span class="read_more">Read more..</span>
              </div>
            </div>
          </a>
        </div>
      <?php endforeach ?>
    </div>
  </div>

  <div class="col-3 col-s-12">
    <div class="aside">
                <!-- post sidebar -->
                <div class="post-sidebar">
                  <div class="card">
                    <div class="card-header">
                      <h2>Topics</h2>
                    </div>
                    <div class="card-content">
                      <?php foreach ($topics as $topic): ?>
                        <a 
                          href="<?php echo BASE_URL . 'filtered_posts.php?topic=' . $topic['id'] ?>">
                          <?php echo $topic['name']; ?>
                        </a> 
                      <?php endforeach ?>
                    </div>
                  </div>
                </div>
                <!-- //post sidebar up -->
                <!-- post sidebar down -->
                <div class="post-sidebar">
                  <div class="card">
                      <div class="card-header">
                        <h2>Recent article</h2>
                      </div>
                      <div class="card-content">
                        <?php $posts = getPublishedPosts(); ?>
                        <?php foreach ($posts as $post): ?>
                        <div class="" style="margin-left: 0px;">
                          <a href="single_post.php?post-slug=<?php echo $post['slug']; ?>">
                            <div class="post_info">
                              <h3><?php echo $post['title'] ?></h3>
                              
                            </div>
                          </a>
                        </div>
                      <?php endforeach ?>
                      </div>
                  </div>
                </div>
            </div>
    </div>
</div> <!-- row end -->

</section>




<section>
<div class="footer">
    <p>Resize the browser window to see how the content respond to the resizing.</p>
    <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>
    <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>
  <p>Resize the browser window to see how the content respond to the resizing.</p>

</div>
</section>

</div>
<!-- container end -->
</body>
</html>
